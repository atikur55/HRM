@extends('layouts.default')
    
    @section('styles')
        
    @endsection

    @section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title">Title</h2>
            </div>    
        </div>

        <div class="row">

        </div>
    </div>
    @endsection
    
    @section('scripts')
    <script type="text/javascript">

    </script>
    @endsection 
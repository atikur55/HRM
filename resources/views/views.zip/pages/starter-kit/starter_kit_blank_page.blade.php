@extends('layouts.app')

@section('content')

            <div class="layout-px-spacing">

                <div class="row layout-top-spacing">


                </div>

            </div>

@endsection
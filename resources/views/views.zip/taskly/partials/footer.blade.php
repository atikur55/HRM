<div class="footer-left">
  Copyright &copy; {{ date('Y') }} <div class="bullet"></div> Design By <a href="http://rajodiya.com" target="_blank">Rajodiya Infotech</a>
</div>

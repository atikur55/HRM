
 <link rel="icon" type="image/x-icon" href="{{asset('cork-white')}}/assets/img/favicon.ico" />
 <link href="{{asset('cork-white')}}/assets/css/loader.css" rel="stylesheet" type="text/css" />
 <script src="{{asset('cork-white')}}/assets/js/loader.js"></script>

 <!-- BEGIN GLOBAL MANDATORY STYLES -->
 <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="{{asset('cork-white')}}/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
 <link href="{{asset('cork-white')}}/assets/css/plugins.css" rel="stylesheet" type="text/css" />
 <!-- END GLOBAL MANDATORY STYLES -->

 <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
 <link href="{{asset('cork-white')}}/plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
 <link href="{{asset('cork-white')}}/assets/css/dashboard/dash_2.css" rel="stylesheet" type="text/css" />
 <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->

 <link href="{{asset('cork-white')}}/assets/css/dashboard/dash_1.css" rel="stylesheet" type="text/css" />

 
 <!-- BEGIN DATATABLE PAGE LEVEL STYLES -->
 <link rel="stylesheet" type="text/css" href="{{asset('cork-white')}}/plugins/table/datatable/datatables.css">
 <link rel="stylesheet" type="text/css" href="{{asset('cork-white')}}/plugins/table/datatable/dt-global_style.css">
 <!-- END DATATABLE PAGE LEVEL STYLES -->

    <!-- BEGIN APP CONTACT LEVEL STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('cork-white')}}/assets/css/forms/theme-checkbox-radio.css">
 <link href="{{asset('cork-white')}}/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css" />
 <link href="{{asset('cork-white')}}/assets/css/apps/contacts.css" rel="stylesheet" type="text/css" />
 <!-- END APP CONTACT LEVEL STYLES -->    


 <!-- Custom css -->
 
 <link href="{{asset('cork-white')}}/assets/css/custome-css/custom-dt.css" rel="stylesheet" type="text/css" />


 <!-- OLD -->
 {{-- <link rel="stylesheet" type="text/css" href="{{ asset('/assets/vendor/bootstrap/css/bootstrap.min.css') }}"> --}}
 {{-- <link rel="stylesheet" type="text/css" href="{{ asset('/assets/vendor/semantic-ui/semantic.min.css') }}"> --}}
 {{-- <link rel="stylesheet" type="text/css" href="{{ asset('/assets/vendor/DataTables/datatables.min.css') }}"> --}}
 {{-- <link rel="stylesheet" type="text/css" href="{{ asset('/assets/vendor/flag-icon-css/css/flag-icon.min.css') }}"> --}}
 {{-- <link rel="stylesheet" type="text/css" href="{{ asset('/assets/css/style.css') }}"> --}}


    <!-- BEGIN PAGE LEVEL STYLES -->
    <link href="{{asset('cork-white')}}/assets/css/apps/scrumboard.css" rel="stylesheet" type="text/css" />
    <link href="{{asset('cork-white')}}/assets/css/forms/theme-checkbox-radio.css" rel="stylesheet" type="text/css">
    <!-- END PAGE LEVEL STYLES -->
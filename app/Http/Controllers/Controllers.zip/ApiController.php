<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Classes\table;
use App\Classes\permission;
use App\Http\Requests;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;

use DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;



class ApiController extends Controller
{
    public function index(){

    $datenow = date('Y-m-d'); 
    // $is_online = table::attendance()->where('date', $datenow)->pluck('idno')->pluck('status_timein')->pluck('status_timeout');

     /* My code */
     $is_timein = table::attendance()->where('date', $datenow)->pluck('status_timein');

    
     $is_timein_arr = json_decode(json_encode($is_timein), true);

    
     $is_timein_now = count($is_timein);

     $is_timeout = table::attendance()->where('date', $datenow)->pluck('status_timeout');

    
     $is_timeout_arr = json_decode(json_encode($is_timeout), true);

    
     $is_timeout_now = count($is_timeout);

    

    
    /* ./My code */

    $is_online = table::attendance()->where('date', $datenow)->pluck('idno');

    
    $is_online_arr = json_decode(json_encode($is_online), true);

    $is_online_now = count($is_online); 

    $emp_ids = table::companydata()->pluck('idno');
    $emp_ids_arr = json_decode(json_encode($emp_ids), true); 
    $is_offline_now = count(array_diff($emp_ids_arr, $is_online_arr));
    $tf = table::settings()->value("time_format");
    
    $emp_all_type = table::people()
    ->join('tbl_company_data', 'tbl_people.id', '=', 'tbl_company_data.reference')
    ->join('tbl_people_attendance', 'tbl_people.id', '=', 'tbl_people_attendance.reference')
    ->where('tbl_people.employmentstatus', 'Active')
    ->where('tbl_people_attendance.date', $datenow)
    ->orderBy('tbl_company_data.startdate', 'desc')
    //->take(8)
    ->select('tbl_people.id','tbl_people.firstname','tbl_people.lastname','tbl_people.avatar','tbl_people_attendance.timein','tbl_people_attendance.timeout','tbl_company_data.department')
    ->get();

    $emp_typeR = table::people()
    ->where('employmenttype', 'Regular')
    ->where('employmentstatus', 'Active')
    ->count();

    $emp_typeT = table::people()
    ->where('employmenttype', 'Trainee')
    ->where('employmentstatus', 'Active')
    ->count();

    $emp_allActive = table::people()
    ->where('employmentstatus', 'Active')
    ->count();

    $a = table::attendance()
    ->latest('date')
    ->where('date',$datenow)
    ->get();
    
    $emp_approved_leave = table::leaves()
    ->where('status', 'Approved')
    ->orderBy('leavefrom', 'desc')
    ->take(8)
    ->get();

    $emp_leaves_approve = table::leaves()
    ->where('status', 'Approved')
    ->count();

    $emp_leaves_pending = table::leaves()
    ->where('status', 'Pending')
    ->count();

    $emp_leaves_all = table::leaves()
    ->where('status', 'Approved')
    ->orWhere('status', 'Pending')
    ->count();

        if ($emp_all_type) {
            return response()->json($emp_all_type , 200);
           } else {
            return response()->json([
                      'type' => 'activity_items',
                      'message' => 'Fail'
                  ], 400);
           }
          }
    
    public function attendanceCount(){
        $datenow = date('Y-m-d'); 
      
    
        $is_online = table::attendance()->where('date', $datenow)->pluck('idno');
    
        
        $is_online_arr = json_decode(json_encode($is_online), true);
    
        $is_online_now = count($is_online); 
    
        $emp_ids = table::companydata()->pluck('idno');
        $emp_ids_arr = json_decode(json_encode($emp_ids), true); 
        $is_offline_now = count(array_diff($emp_ids_arr, $is_online_arr));
        $total = $is_online_now+$is_offline_now;
          $tf = table::settings()->value("time_format");
    
    $emp_all_type = table::people()
    ->join('tbl_company_data', 'tbl_people.id', '=', 'tbl_company_data.reference')
    ->join('tbl_people_attendance', 'tbl_people.id', '=', 'tbl_people_attendance.reference')
    ->where('tbl_people.employmentstatus', 'Active')
    ->where('tbl_people_attendance.date', $datenow)
    ->orderBy('tbl_company_data.startdate', 'desc')
    //->take(8)
    ->get();

    $emp_typeR = table::people()
    ->where('employmenttype', 'Regular')
    ->where('employmentstatus', 'Active')
    ->count();

    $emp_typeT = table::people()
    ->where('employmenttype', 'Trainee')
    ->where('employmentstatus', 'Active')
    ->count();

    $emp_allActive = table::people()
    ->where('employmentstatus', 'Active')
    ->count();

    $a = table::attendance()
    ->latest('date')
    ->where('date',$datenow)
    ->get();
    
    $emp_approved_leave = table::leaves()
    ->where('status', 'Approved')
    ->orderBy('leavefrom', 'desc')
    ->take(8)
    ->get();

    $emp_leaves_approve = table::leaves()
    ->where('status', 'Approved')
    ->count();

    $emp_leaves_pending = table::leaves()
    ->where('status', 'Pending')
    ->count();

    $emp_leaves_all = table::leaves()
    ->where('status', 'Approved')
    ->orWhere('status', 'Pending')
    ->count();
    
        $arr  = array(
            'timein'=>$is_online_now,
            'ntimein' =>$is_offline_now,
            'totla'=>$total,
            'emp_typeR'=> $emp_typeR,
            'emp_typeT'=>$emp_typeT,
            'emp_leaves_approve'=>$emp_leaves_approve,
            'emp_leaves_all'=>$emp_leaves_all
            
            
            );
        
       
    
            if ($arr) {
                return response()->json($arr , 200);
               } else {
                return response()->json([
                          'type' => 'activity_items',
                          'message' => 'Fail'
                      ], 400);
               }
        }
        
            public function employeeData(){

    $datenow = date('Y-m-d'); 
    // $is_online = table::attendance()->where('date', $datenow)->pluck('idno')->pluck('status_timein')->pluck('status_timeout');

     /* My code */
     $is_timein = table::attendance()->where('date', $datenow)->pluck('status_timein');

    
     $is_timein_arr = json_decode(json_encode($is_timein), true);

    
     $is_timein_now = count($is_timein);

     $is_timeout = table::attendance()->where('date', $datenow)->pluck('status_timeout');

    
     $is_timeout_arr = json_decode(json_encode($is_timeout), true);

    
     $is_timeout_now = count($is_timeout);

    

    
    /* ./My code */

    $is_online = table::attendance()->where('date', $datenow)->pluck('idno');

    
    $is_online_arr = json_decode(json_encode($is_online), true);

    $is_online_now = count($is_online); 

    $emp_ids = table::companydata()->pluck('idno');
    $emp_ids_arr = json_decode(json_encode($emp_ids), true); 
    $is_offline_now = count(array_diff($emp_ids_arr, $is_online_arr));
    $tf = table::settings()->value("time_format");
    
    $emp_all_type = table::people()
    ->join('tbl_company_data', 'tbl_people.id', '=', 'tbl_company_data.reference')
    ->orderBy('tbl_company_data.startdate', 'desc')
    //->take(8)
    ->select('tbl_people.id','tbl_people.firstname','tbl_people.lastname','tbl_people.employmentstatus','tbl_company_data.department','tbl_company_data.idno','tbl_people.avatar')
    // ->distinct()
    ->get();
    
    // $c = table::people()
    // ->get();
    // echo 'test';
    // dd($c);

    $emp_typeR = table::people()
    ->where('employmenttype', 'Regular')
    ->where('employmentstatus', 'Active')
    ->count();

    $emp_typeT = table::people()
    ->where('employmenttype', 'Trainee')
    ->where('employmentstatus', 'Active')
    ->count();

    $emp_allActive = table::people()
    ->where('employmentstatus', 'Active')
    ->count();

    $a = table::attendance()
    ->latest('date')
    ->where('date',$datenow)
    ->get();
    
    $emp_approved_leave = table::leaves()
    ->where('status', 'Approved')
    ->orderBy('leavefrom', 'desc')
    ->take(8)
    ->get();

    $emp_leaves_approve = table::leaves()
    ->where('status', 'Approved')
    ->count();

    $emp_leaves_pending = table::leaves()
    ->where('status', 'Pending')
    ->count();

    $emp_leaves_all = table::leaves()
    ->where('status', 'Approved')
    ->orWhere('status', 'Pending')
    ->count();

        if ($emp_all_type) {
            return response()->json($emp_all_type , 200);
           } else {
            return response()->json([
                      'type' => 'activity_items',
                      'message' => 'Fail'
                  ], 400);
           }
          }
          
    public function empSingle($id){
        if($id){
            $data = table::people()
                ->join('tbl_company_data', 'tbl_people.id', '=', 'tbl_company_data.reference')
               ->where('tbl_people.id',$id)
            ->first();
            
              if ($data) {
                return response()->json($data , 200);
               } else {
                return response()->json([
                          'type' => 'activity_items',
                          'message' => 'Fail'
                      ], 400);
               }
        }else{
            echo 'no data found';
        }
    }
    
        public function attendance() 
    {
        
        
        $data = table::attendance()->orderBy('date', 'desc')->get();
       
        // $ss = table::settings()->select('clock_comment', 'time_format')->first();
        // $employees = table::people()->get();
        // $tf = table::settings()->value("time_format");
        // $cc = table::settings()->value("clock_comment");
        
            if ($data) {
                return response()->json($data , 200);
               } else {
                return response()->json([
                          'type' => 'activity_items',
                          'message' => 'Fail'
                      ], 400);
               }
    }

}
